module.exports = {
  HOST: "localhost",
  PORT: 4444,
  USERNAME: "root",
  PASSWORD: "manager",
  DATABASE: "project_db",
  USER_TABLE: "users",
  BOOK_TABLE: "books",
  // PURCHASE_TABLE: "purchase",
};
