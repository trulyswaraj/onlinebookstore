const USER_URL = "http://192.168.1.6:4444/user";
const BOOK_URL = "http://192.168.1.6:4444/book";

export { USER_URL, BOOK_URL };